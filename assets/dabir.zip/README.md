# Dabir
Dabir is a calliography typeface designed to complete <a href="https://maryamsoft.com/product/fontshop/main/dabir-htm" target="_blank">Dabir typeface</a> designed by <a href="http://www.amirmahdimoslehi.com/" target="_blank">Amir Mahdi Moslehi</a>.

![InShot_20210426_005550318](https://user-images.githubusercontent.com/25493297/116008521-40be9080-a62a-11eb-981e-a0b5fb5a8095.jpg)

## Roadmap
- [ ] adding marks to all glyphs and using `ccmp` to extend unicode range support.
- [ ] design higher weights, contrast levels and multiple width classes.
- [ ] variable version.
- [ ] github test page.
